# Authors

* [Morris Jobke](https://github.com/MorrisJobke): <hey@morrisjobke.de>

## Designers

* [Jan-Christoph Borchardt](https://github.com/jancborchardt): <hey@jancborchardt.net>
* [Morris Jobke](https://github.com/MorrisJobke): <hey@morrisjobke.de>

## Contributors

* [Leizh](https://github.com/eizh): <leizh@free.fr>
* [Thomas Müller](https://github.com/DeepDiver1975): <github@tmit.eu>
* [Jörn Friedrich Dreyer](https://github.com/butonic): <d@butonic.de>
* [7ebra](https://github.com/7ebra)
* [Felix Böhm](https://github.com/felixboehm)
* [selpelt](https://github.com/selpelt)
* [Xefir](https://github.com/Xefir)
* [Ralf Pietsch](https://github.com/AlZiBa)
* [Glandos](https://github.com/Glandos)
* [jbtbnl](https://github.com/jbtbnl)
* [arboss](https://github.com/arboss)
* [Volkan Gezer](https://github.com/wakeup)
* [Christopher Schäpers](https://github.com/Kondou-ger): <christopher@schaepers.it>
* [Pellaeon Lin](https://github.com/pellaeon): <nfsmwlin@gmail.com>
* [Gigen Chang](https://github.com/gigenchang): <th33ts@gmail.com>
