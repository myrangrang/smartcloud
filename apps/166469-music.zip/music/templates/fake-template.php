<!--  this template is just a fake template it's purpose is to get fetched
while extraction, because this string is located in PHP code -->
<span translate>Music</span>
<span translate>Unknown album</span>
<span translate>Unknown artist</span>
<span translate>Artists</span>
<span translate>Albums</span>
<span translate>Tracks</span>
<span translate>Path to your music collection</span>
<span translate>Invalid path</span>
<span translate>This setting specifies the folder which will be scanned for music.</span>
<span translate>Use this address to browse your music collection from any Ampache compatible player.</span>
<span translate>Description</span>
<span translate>Description (e.g. App name)</span>
<span translate>Generate API password</span>
<span translate>Revoke API password</span>
<span translate>Use your username and following password to connect to this Ampache instance:</span>
<span translate>Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime.</span>
<span translate>Keep in mind, that the Ampache API is just a preview and is unstable. Feel free to report your experience with this feature in the corresponding <a href="https://github.com/owncloud/music/issues/60">issue</a>. I would also like to have a list of clients to test with. Thanks</span>

