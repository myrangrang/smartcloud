<?php
$TRANSLATIONS = array(
"_Show all {{ trackcount }} songs ..._::_Show all {{ trackcount }} songs ..._" => array("","")
);
$PLURAL_FORMS = "nplurals=2; plural=n > 1;";
