<?php
$TRANSLATIONS = array(
"Albums" => "Албуми",
"Artists" => "Артисти",
"Description" => "Опис",
"Description (e.g. App name)" => "Опис (нпр. име на апликацијата)",
"Generate API password" => "Генерирај API лозинка",
"Invalid path" => "Грешна патека",
"Music" => "Музика",
"Next" => "Следно",
"Path to your music collection" => "Патека до вашата музичка колекција",
"Pause" => "Пауза",
"Play" => "Пушти",
"Previous" => "Претходно",
"Repeat" => "Повтори",
"Revoke API password" => "Отповикај ја API лозинката",
"Shuffle" => "Помешај",
"Some not playable tracks were skipped." => "Некои песни кои не можеа да се пуштат беа прескокнати.",
"This setting specifies the folder which will be scanned for music." => "Овие поставки го одредуваат фолдерот кој ќе биде прегледан за музика.",
"Tracks" => "Песна",
"Unknown album" => "Непознат албум",
"Unknown artist" => "Непознат артист"
);
$PLURAL_FORMS = "nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;";
