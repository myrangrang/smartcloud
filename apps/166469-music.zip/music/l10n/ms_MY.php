<?php
$TRANSLATIONS = array(
"Description" => "Keterangan",
"Music" => "Muzik",
"Next" => "Seterus",
"Pause" => "Jeda",
"Play" => "Main",
"Previous" => "Sebelum",
"Repeat" => "Ulang",
"Shuffle" => "Kocok"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
