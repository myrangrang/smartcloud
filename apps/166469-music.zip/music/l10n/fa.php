<?php
$TRANSLATIONS = array(
"Albums" => "آلبوم ها",
"Artists" => "هنرمندان",
"Description" => "توضیحات",
"Invalid path" => "مسیر اشتباه",
"Music" => "موزیک",
"Next" => "بعدی",
"Pause" => "توقف کردن",
"Play" => "پخش کردن",
"Previous" => "قبلی",
"Repeat" => "تکرار",
"Shuffle" => "درهم"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
