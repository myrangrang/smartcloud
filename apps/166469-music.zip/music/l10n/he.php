<?php
$TRANSLATIONS = array(
"Description" => "תיאור",
"Music" => "מוזיקה",
"Next" => "הבא",
"Pause" => "השהה",
"Play" => "נגן",
"Previous" => "קודם",
"Repeat" => "חזרה",
"Shuffle" => "ערבב",
"Unknown album" => "אלבום לא ידוע",
"Unknown artist" => "אמן לא ידוע"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
