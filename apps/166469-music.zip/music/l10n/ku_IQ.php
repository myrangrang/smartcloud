<?php
$TRANSLATIONS = array(
"Description" => "پێناسه",
"Music" => "مۆسیقا",
"Next" => "دوواتر",
"Pause" => "وه‌ستان",
"Play" => "لێدان",
"Previous" => "پێشووتر"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
