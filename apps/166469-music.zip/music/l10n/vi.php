<?php
$TRANSLATIONS = array(
"Description" => "Mô tả",
"Music" => "Âm nhạc",
"Next" => "Kế tiếp",
"Pause" => "Tạm dừng",
"Play" => "Play",
"Previous" => "Lùi lại",
"Repeat" => "Lặp lại",
"Shuffle" => "Ngẫu nhiên",
"Unknown album" => "Không tìm thấy album",
"Unknown artist" => "Không tìm thấy nghệ sĩ"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
