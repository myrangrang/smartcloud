<?php
$TRANSLATIONS = array(
"Description" => "Përshkrimi",
"Music" => "Muzikë",
"Next" => "Mëpasshëm",
"Pause" => "Pauzë",
"Play" => "Luaj",
"Previous" => "Mëparshëm",
"Repeat" => "Përsëritet",
"Shuffle" => "Përziej"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
