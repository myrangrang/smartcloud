<?php
$TRANSLATIONS = array(
"Description" => "විස්තරය",
"Music" => "සංගීතය",
"Next" => "ඊලඟ",
"Pause" => "විරාමය",
"Play" => "ධාවනය",
"Previous" => "පෙර",
"Repeat" => "පුනරාවර්ථන"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
