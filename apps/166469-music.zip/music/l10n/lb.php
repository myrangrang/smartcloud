<?php
$TRANSLATIONS = array(
"Description" => "Beschreiwung",
"Music" => "Musek",
"Next" => "Weider",
"Pause" => "Paus",
"Play" => "Ofspillen",
"Previous" => "Zeréck",
"Repeat" => "Widderhuelen"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
