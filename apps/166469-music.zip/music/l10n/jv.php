<?php
$TRANSLATIONS = array(
"Music" => "Gamelan",
"Next" => "Sak bare",
"Play" => "Puter",
"Previous" => "Sak durunge"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
