<?php
$TRANSLATIONS = array(
"Description" => "ဖော်ပြချက်"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
