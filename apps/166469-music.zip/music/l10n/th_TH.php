<?php
$TRANSLATIONS = array(
"Description" => "คำอธิบาย",
"Music" => "เพลง",
"Next" => "ถัดไป",
"Pause" => "หยุดชั่วคราว",
"Play" => "เล่น",
"Previous" => "ก่อนหน้า",
"Repeat" => "ทำซ้ำ"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
