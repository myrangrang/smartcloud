<?php
$TRANSLATIONS = array(
"Description" => "Descripcion",
"Music" => "Musica",
"Next" => "Venent",
"Pause" => "Pausa",
"Play" => "Fai tirar",
"Previous" => "Darrièr",
"Repeat" => "Torna far"
);
$PLURAL_FORMS = "nplurals=2; plural=(n > 1);";
