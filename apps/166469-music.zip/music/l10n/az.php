<?php
$TRANSLATIONS = array(
"Albums" => "Albomlar",
"Artists" => "Müğənnilər",
"Description" => "Açıqlanma",
"Description (e.g. App name)" => "Açıqlanma(Misal üçün proqram adı)",
"Generate API password" => "APİ şifrəsinin generasiyası",
"Here you can generate passwords to use with the Ampache API, because they can't be stored in a really secure way due to the design of the Ampache API. You can generate as many passwords as you want and revoke them anytime." => "Ampache APİ-nin istifadə edilməsi üçün burda siz şifrələr generasiya edə bilərsiniz ona görə ki, onlar yalnz təhlükəsiz saxlana bilər. Bu Ampache API-nin öz dizaynıdır. Siz istənilən zaman çoxlu şifrə yarada və onları silə bilərsiniz.",
"Music" => "Musiqi",
"Next" => "Növbəti",
"Path to your music collection" => "Sizin musiqi yığmasının ünvanı",
"Repeat" => "Təkrar"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
