<?php
$TRANSLATIONS = array(
"Description" => "Skildring",
"Music" => "Musikk",
"Next" => "Neste",
"Pause" => "Pause",
"Play" => "Spel",
"Previous" => "Førre",
"Repeat" => "Gjenta"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
