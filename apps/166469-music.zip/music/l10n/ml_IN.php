<?php
$TRANSLATIONS = array(
"Music" => "സംഗീതം",
"Next" => "അടുത്തത്",
"Pause" => " നിറുത്ത്",
"Play" => "തുടങ്ങുക",
"Previous" => "മുന്‍പത്തേത്"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
