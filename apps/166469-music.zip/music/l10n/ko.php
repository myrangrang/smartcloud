<?php
$TRANSLATIONS = array(
"Albums" => "앨범",
"Artists" => "음악가",
"Description" => "종류",
"Generate API password" => "API 비밀번호 생성",
"Music" => "음악",
"Next" => "다음",
"Pause" => "일시 정지",
"Play" => "재생",
"Previous" => "이전",
"Repeat" => "반복",
"Shuffle" => "임의 재생",
"Unknown album" => "알려지지 않은 앨범",
"Unknown artist" => "알려지지 않은 아티스트"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
