<?php
$TRANSLATIONS = array(
"Description" => "Beschreibung",
"Music" => "Musik",
"Next" => "Nächstes",
"Pause" => "Pause",
"Play" => "Abspielen",
"Previous" => "Vorheriges",
"Repeat" => "Wiederholen",
"Shuffle" => "Zufallswiedergabe",
"Unknown album" => "Unbekanntes Album",
"Unknown artist" => "Unbekannter Künstler"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
