<?php
$TRANSLATIONS = array(
"Music" => "Tónlist",
"Next" => "Næst",
"Pause" => "Pása",
"Play" => "Spila",
"Previous" => "Fyrra"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
