<?php
$TRANSLATIONS = array(
"Description" => "Նկարագրություն"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
