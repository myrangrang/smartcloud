<?php
$TRANSLATIONS = array(
"Description" => "چۈشەندۈرۈش",
"Music" => "نەغمە",
"Next" => "كېيىنكى",
"Pause" => "ۋاقىتلىق توختا",
"Play" => "چال",
"Previous" => "ئالدىنقى",
"Repeat" => "قايتىلا"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
