<?php
$TRANSLATIONS = array(
"Description" => "Description",
"Music" => "Musica",
"Next" => "Proxime",
"Pause" => "Pausa",
"Play" => "Reproducer",
"Previous" => "Previe",
"Repeat" => "Repeter"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
