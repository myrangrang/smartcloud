<?php
$TRANSLATIONS = array(
"Music" => "音樂",
"Next" => "下一首",
"Pause" => "暫停",
"Play" => "播放",
"Previous" => "上一首"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
