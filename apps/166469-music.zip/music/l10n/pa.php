<?php
$TRANSLATIONS = array(
"Music" => "ਸੰਗੀਤ"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
