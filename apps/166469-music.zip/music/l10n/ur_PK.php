<?php
$TRANSLATIONS = array(
"Description" => "تصریح",
"Next" => "اگلا",
"Repeat" => "دہرایں"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
