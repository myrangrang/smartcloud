<?php
$TRANSLATIONS = array(
"Description" => "Deskripzioa",
"Music" => "Musika",
"Next" => "Aurrera",
"Pause" => "geldi",
"Play" => "jolastu",
"Previous" => "Atzera",
"Repeat" => "Errepikatu"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
