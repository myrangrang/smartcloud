<?php
$TRANSLATIONS = array(
"Music" => "సంగీతం",
"Next" => "తదుపరి",
"Previous" => "గత"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
