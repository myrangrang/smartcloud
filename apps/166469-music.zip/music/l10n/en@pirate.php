<?php
$TRANSLATIONS = array(
"Music" => "Music",
"Pause" => "Pause"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
