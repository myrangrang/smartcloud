<?php
$TRANSLATIONS = array(
"Description" => "Beschreibung",
"Music" => "Musik",
"Next" => "Weiter",
"Pause" => "Anhalten",
"Play" => "Abspielen",
"Previous" => "Vorheriges",
"Repeat" => "Wiederholen"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
