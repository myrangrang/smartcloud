<?php
$TRANSLATIONS = array(
"Description" => "Penjelasan",
"Music" => "Musik",
"Next" => "Selanjutnya",
"Pause" => "Jeda",
"Play" => "Putar",
"Previous" => "Sebelumnya",
"Repeat" => "Ulangi",
"Shuffle" => "Acak"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
