<?php
$TRANSLATIONS = array(
"Albums" => "អាល់ប៊ុម",
"Artists" => "សិល្បករ",
"Description" => "ការ​អធិប្បាយ",
"Description (e.g. App name)" => "ការ​អធិប្បាយ (ឧ. ឈ្មោះ​កម្មវិធី)",
"Generate API password" => "បង្កើត​ពាក្យ​សម្ងាត់ API",
"Invalid path" => "ទីតាំង​មិន​ត្រឹម​ត្រូវ",
"Music" => "តន្ត្រី",
"Next" => "បន្ទាប់",
"Pause" => "ផ្អាក",
"Play" => "លេង",
"Previous" => "មុន",
"Repeat" => "ធ្វើម្ដងទៀត",
"Shuffle" => "បង្អូស",
"Tracks" => "បទ",
"Unknown album" => "អាល់ប៊ុមអត់​ឈ្មោះ",
"Unknown artist" => "សិល្បករអត់​ឈ្មោះ"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
