<?php
$TRANSLATIONS = array(
"Albums" => "Diskak",
"Artists" => "Artistak",
"Description" => "Deskribapena",
"Description (e.g. App name)" => "Deskribapena (adb. App izena)",
"Generate API password" => "Sortu API pasahitza",
"Invalid path" => "Baliogabeko bidea",
"Music" => "Musika",
"Next" => "Hurrengoa",
"Path to your music collection" => "Musika bildumaren bidea",
"Pause" => "Pausarazi",
"Play" => "Erreproduzitu",
"Previous" => "Aurrekoa",
"Repeat" => "Errepikatu",
"Revoke API password" => "Ezeztatu API pasahitza",
"Shuffle" => "Nahastu",
"Some not playable tracks were skipped." => "Erreproduzitu ezin ziren pista batzuk saltatu egin dira.",
"This setting specifies the folder which will be scanned for music." => "Hemen musika bilatuko den karpetak zehazten dira.",
"Tracks" => "Pistak",
"Unknown album" => "Diska ezezaguna",
"Unknown artist" => "Artista ezezaguna",
"Use this address to browse your music collection from any Ampache compatible player." => "Erabili helbide hau zure musika bilduma Ampacherekin bateragarria den edozein erreproduktorekin arakatzeko.",
"Use your username and following password to connect to this Ampache instance:" => "Erabili zure erabiltzaile izena eta hurrengo pasahitza Ampache honetara konektatzeko:"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
