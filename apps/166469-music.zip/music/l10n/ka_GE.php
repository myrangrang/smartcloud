<?php
$TRANSLATIONS = array(
"Description" => "გვერდის დახასიათება",
"Music" => "მუსიკა",
"Next" => "შემდეგი",
"Pause" => "პაუზა",
"Play" => "დაკვრა",
"Previous" => "წინა",
"Repeat" => "გამეორება"
);
$PLURAL_FORMS = "nplurals=1; plural=0;";
