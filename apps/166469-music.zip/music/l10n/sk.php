<?php
$TRANSLATIONS = array(
"Description" => "Popis",
"Repeat" => "Opakovať"
);
$PLURAL_FORMS = "nplurals=3; plural=(n==1) ? 0 : (n>=2 && n<=4) ? 1 : 2;";
