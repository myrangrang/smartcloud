<?php
$TRANSLATIONS = array(
"Description" => "Descripción",
"Music" => "Música",
"Next" => "Siguiente",
"Pause" => "Pausa",
"Play" => "Reproducir",
"Previous" => "Anterior",
"Repeat" => "Repetir",
"Shuffle" => "Mezclar"
);
$PLURAL_FORMS = "nplurals=2; plural=(n != 1);";
