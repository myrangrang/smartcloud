#ocDashboard

This is some kind of framework for widgets (inclusive standard widgets) in a dashboard for owncloud.

Descriptions and Bugtracker: https://github.com/fjies/ocDashboard
Download and information: freans.de/owncloud

##requirements

###version 1.3
developed and tested  with

 * owncloud 7
 * mysql (sqlite will not work)
 * PHP >= 5

no appframework needed yet

###version <= 1.2
developed and tested with

 * 6.0.3
 * mysql (sqlite will not work)
 * PHP >= 5

###Newsreader
 * news app >= 2.002

###Mailcheck
 * imap apache modul

###Weather
 * file_get_contents needed

## Knowen Bugs verion >= 1.3

## Knowen Bugs verion <= 1.2

###Widgets
####Tasks
If you add a new task, you can not mark it as done before you reload the page.
The js click bind is missing.

##Everything else
Proud to use phpStorm.