# Readme ocDashboard

##Informations, Bugs and Development
https://github.com/fjies/ocDashboard
http://apps.owncloud.com/content/show.php/ocDashboard?content=160265

##Contact
Florian Steffens
webmaster@freans.de