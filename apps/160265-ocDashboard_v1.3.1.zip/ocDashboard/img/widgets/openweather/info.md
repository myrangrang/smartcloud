# Icons
Icons are downloaded from here:

    http://bugs.openweathermap.org/projects/api/wiki/Weather_Condition_Codes
