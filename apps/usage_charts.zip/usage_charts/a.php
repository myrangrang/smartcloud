<!DOCTYPE html>
<html>
<title>Hello Strapdown</title>
<xmp>
<?php include 'README.md';?>
</xmp>

<script src="http://strapdownjs.com/v/0.2/strapdown.js"></script>
</html>