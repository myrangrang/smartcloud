ocUsageCharts DataProviders
===========================
DataProviders are responsible for the retrieving and storing of the data for that specific chart type
Implement DataProviderInterface to actually add multiple charts.