<?php
$TRANSLATIONS = array(
    "ocUsageCharts"         => "Gráficos",
    "StorageUsageLastMonth" => "Uso de disco el último mes",
    "StorageUsagePerMonth"  => "Uso promedio de disco por mes",
    "StorageUsageCurrent"   => "Uso actual de disco",
    "DefaultChartSize"      => "The charts will be shown in this size",
    "sizes_kb"              => "Kilobytes",
    "sizes_mb"              => "Megabytes",
    "sizes_gb"              => "Gigabytes",
    "sizes_tb"              => "Terabytes"
);
