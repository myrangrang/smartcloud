<?php
$TRANSLATIONS = array(
    "ocUsageCharts"         => "Graphes",

    "Storage_title"         => "Espace disque",
    "StorageUsageLastMonth" => "Espace disque - 30 derniers jours",
    "StorageUsagePerMonth"  => "Espace disque - Moyenne mensuelle",
    "StorageUsageCurrent"   => "Espace disque - Aujourd'hui",
    "DefaultChartSize"      => "Unités",
    "sizes_kb"              => "Kilobytes",
    "sizes_mb"              => "Megabytes",
    "sizes_gb"              => "Gigabytes",
    "sizes_tb"              => "Terabytes",

    "Activity_title"        => "Activité",
    "ActivityUsageLastMonth"=> "Activité - 30 derniers jours",
    "activities"            => "Activité",
    "ActivityUsagePerMonth" => "Activité - Moyenne mensuelle",
);