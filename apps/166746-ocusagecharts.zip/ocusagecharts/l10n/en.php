<?php
$TRANSLATIONS = array(
    "ocUsageCharts"         => "Charts",

    "Storage_title"         => "Storage Usage",
    "StorageUsageLastMonth" => "Storage usage last month",
    "StorageUsagePerMonth"  => "Average storage usage per month",
    "StorageUsageCurrent"   => "Current storage usage",
    "DefaultChartSize"      => "The charts will be shown in this size",
    "sizes_kb"              => "Kilobytes",
    "sizes_mb"              => "Megabytes",
    "sizes_gb"              => "Gigabytes",
    "sizes_tb"              => "Terabytes",

    "ActivityUsageLastMonth"=> "Activities over the last month",
    "activities"            => "Activities",
    "ActivityUsagePerMonth" => "Activities per month",
    "Activity_title"        => "Activities"
);