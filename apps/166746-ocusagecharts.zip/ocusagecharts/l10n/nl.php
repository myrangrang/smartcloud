<?php
$TRANSLATIONS = array(
    "ocUsageCharts"         => "Grafieken",

    "Storage_title"         => "Data verbruik",
    "StorageUsageLastMonth" => "Data verbruik de afgelopen maand",
    "StorageUsagePerMonth"  => "Gemiddelde data verbruik per maand",
    "StorageUsageCurrent"   => "Huidig data verbruik",
    "DefaultChartSize"      => "De grafieken worden weergegeven in deze grootte",
    "sizes_kb"              => "Kilobytes",
    "sizes_mb"              => "Megabytes",
    "sizes_gb"              => "Gigabytes",
    "sizes_tb"              => "Terabytes",

    "ActivityUsageLastMonth"=> "Activiteiten over de afgelopen maand",
    "activities"            => "Activiteiten",
    "ActivityUsagePerMonth" => "Activiteiten per maand",
    "Activity_title"        => "Activiteiten"
);