The current version sadly doesn't support OC6 anymore. But the latest beta for OC6 will be included in the download.
This build was tested with OC7.0.2 of 15.10.2014

--------------------------------------------------------------

support: patrick@gen7.de

Installation 
------------

- copy the files_w2g (from the "Owncloud 6" or "Owncloud 7+" folder) to your apps folder inside your Owncloud installation.

- That's all, database table setup and other stuff will be done automatically


Language support

- FR	Translation by Rachid Mokrani (rachid.mokrani@ifpen.fr)
- JP	Translation by Tetsuro Yano (ynote)

Please make sure to use the correct version!!
