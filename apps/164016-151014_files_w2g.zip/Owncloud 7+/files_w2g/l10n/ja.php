﻿<?php
$TRANSLATIONS = array(
"File not locked" => "ファイルロック無し",
"File is locked" => "ファイルロック中",
"Status: locked" => "状態: ロック中",
"Status: not locked" => "状態: ロック無し",
"filelock" => "ファイルロック",
"Manage multiaccess" => "同時アクセス管理",
"Here you can set the colors for the locked files." => "ロックされたファイルのデフォルトの背景色を設定できます。",
"Background color" => "背景色",
"Font color" => "フォント色",
"Save" => "保存",
"There are no locked files at the moment" => "現在ロックされているファイルはありません",
"Locked files" => "このファイルをロック解除",
"Unlock this file" => "ロック中のファイル",
"Unlock all files" => "全てのファイルをロック解除",
"by" => "による",
);