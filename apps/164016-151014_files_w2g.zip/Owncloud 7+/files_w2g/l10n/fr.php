﻿<?php
$TRANSLATIONS = array(
"File not locked" => "Fichier non verrouillé ",
"File is locked" => " Fichier verrouillé ",
"Status: locked" => " Statut: verrouillé ",
"Status: not locked" => " Statut: non verrouillé ",
"filelock" => "fichier vérouillé",
"Manage multiaccess" => " Configuration des accès multiples",
"Here you can set the colors for the locked files." => " Vous pouvez définir les couleurs pour les fichiers verrouillés.",
"Background color" => " Couleur de fond ",
"Font color" => " Couleur de police ",
"Save" => "Sauvegarder",
"There are no locked files at the moment" => " Il n'y a pas de fichiers verrouillés actuellement",
"Locked files" => " Fichiers verrouillés",
"Unlock this file" => " Déverrouiller ce fichier ",
"Unlock all files" => " Déverrouiller tous les fichiers",
"by" => "par",
);