<?php
$TRANSLATIONS = array(
"File not locked" => "File not locked",
"File is locked" => "File is locked",
"Status: locked" => "Status: locked",
"Status: not locked" => "Status: not locked",
"filelock" => "filelock"
);
