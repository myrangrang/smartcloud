<?php
$TRANSLATIONS = array(
"File not locked" => "Datei nicht gesperrt",
"File is locked" => "Datei ist gesperrt",
"Status: locked" => "Status: gesperrt",
"Status: not locked" => "Status: nicht gesperrt",
"filelock" => "Dateisperre",
"Multi file access" => "Mehrfachzugriff",
"configuration" => "konfigurieren",
"You can choose the backcolor for locked files in the file list" => "Hier können Sie die Standard Hintergrundfarbe für gesperrte Dateien festlegen.",
"You can set an additional font color" => "Schriftfarbe bei gesperrten Dateien",
"Save background color" => "Hintergrundfarbe speichern",
"Save font color" => "Schriftfarbe speichern",
);