User Photo
==========

<em>application of ownCloud</em> :-).

Supply a field to store the user's photo.

Changelog
---------

### version 0.5

+ migration to github ...