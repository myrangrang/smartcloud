owncloud-virustotal
===================

Owncloud Plugin to check for file score on virustotal.com.


Installation
------------

- Copy the checksum folder in the app directory of owncloud.
- Edit ajax/virustotal.com and add your VT API key (line 17).
- Enable this app in the admin interface.


Usage
-----

An info-icon appears on every file. Click it, to get its VT score.
