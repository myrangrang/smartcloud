<?php
/**
 * Dependencies
 */
// Jquery
OCP\Util::addScript("3rdparty", "chosen/chosen.jquery.min");
// virustotal script
OCP\Util::addScript('virustotal', "virustotal" );
