### 2015, 21 March (V 2.0.1)

* Fix selected items issue

### 2015, 07 March (V 2)

* Tiny icons (thanks IzzySoft : https://github.com/SansPseudoFix/Oc-old-menu-stylish/issues/1)

### 2014, 30 Novermber (V 1.2.1):

* add necessary !important

### 2014, 15 November (V 1.2):

* Fix issue https://github.com/SansPseudoFix/Old_menu/issues/2

### 2014, 02 November (V 1.1) :

* Remove useless !important

### 2014, 22 September

* fix issue with [owncloud-markdown](https://github.com/icewind1991/owncloud-markdown) app
* menu top-right background changed
* some refactors

### 2014, 15 September 

* change background-color to match the top bar ([thx lub](https://github.com/SansPseudoFix/Old_menu/pull/1))
